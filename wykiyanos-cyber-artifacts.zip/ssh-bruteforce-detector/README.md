# SSH Brute Force Detector (Mini SIEM Lab)

**Goal:** Detect SSH brute-force activity in Linux auth logs and produce an analyst-friendly report.

**Evidence produced:** Python detector, sample `auth.log`, CSV of top offending IPs, and a written report with findings and suggested response actions.

**How to run** (optional):
```bash
python3 src/detect.py data/auth.log --threshold 5
```
This prints the top source IPs, writes `outputs/top_ips.csv`, and generates `outputs/report.md`.

**Skills:** Log analysis, regex, incident triage, evidence capture, automation with Python.
