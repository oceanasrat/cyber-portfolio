import re, argparse
from collections import Counter
from pathlib import Path

pat_ip = re.compile(r'(?:\d{1,3}\.){3}\d{1,3}')

def parse(path):
    fails, accepts = [], []
    with open(path,'r',errors='ignore') as f:
        for line in f:
            if 'Failed password' in line:
                m = pat_ip.search(line)
                if m: fails.append((m.group(), line.strip()))
            elif 'Accepted password' in line:
                m = pat_ip.search(line)
                if m: accepts.append((m.group(), line.strip()))
    return fails, accepts

def main():
    import sys
    ap = argparse.ArgumentParser()
    ap.add_argument('log')
    ap.add_argument('--threshold', type=int, default=5)
    args = ap.parse_args()
    fails, accepts = parse(args.log)
    ctr = Counter([ip for ip,_ in fails])
    print('Top source IPs by failed attempts:')
    for ip, n in ctr.most_common(10):
        print(f'{ip:15} -> {n} fails')
    outdir = Path('outputs'); outdir.mkdir(exist_ok=True, parents=True)
    with open(outdir/'top_ips.csv','w') as f:
        f.write('ip,failed_attempts\n')
        for ip,n in ctr.most_common():
            f.write(f'{ip},{n}\n')
    suspicious = [ip for ip,n in ctr.items() if n >= args.threshold]
    with open(outdir/'report.md','w') as f:
        f.write('# SSH Brute Force Detector Report\n\n')
        f.write(f'**Threshold:** >= {args.threshold} failed attempts per IP.\n\n')
        f.write('## Suspicious IPs\n')
        for ip in suspicious:
            f.write(f'- {ip} ({ctr[ip]} fails)\n')
        f.write('\n## Recommended actions\n')
        f.write('- Block offending IPs at firewall or fail2ban.\n')
        f.write('- Enforce key-based auth, disable password auth for root.\n')
        f.write('- Review accepted logins for anomalies.\n')
    print('\nOutputs written to ./outputs')

if __name__ == '__main__':
    main()
