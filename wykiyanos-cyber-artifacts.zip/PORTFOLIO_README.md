# Wykiyanos — Evidence Labs

This bundle includes five small but **verifiable** security projects you can publish:

1. `ssh-bruteforce-detector/` — Python log analysis lab
2. `windows-kql-playbook/` — KQL detections for Windows
3. `phishing-triage-case01/` — Header + IOC analysis
4. `vuln-assessment-lab-nmap/` — Nmap triage & remediation
5. `botium-toys-internal-audit/` — Controls checklist + recommendations
