# Findings & Verdict

**Verdict:** Malicious (phishing).

**Key evidence**
- SPF **fail** and DMARC **none**.
- Attachment is executable disguised as PDF: `invoice_2025_11.pdf.exe`.
- Sending domain typosquatted: `secure-inv0ice.example` (uses zero instead of 'o').
- Source IP `203.0.113.77` not previously seen in sender baseline.

**IOCs**
- Domain: `secure-inv0ice.example`
- Source IP: `203.0.113.77`
- Subject: `RE: Overdue invoice 2025-11`
- Attachment hash (sha256): (placeholder for lab)

**Recommended actions**
1. Block sender domain and IP at mail gateway.
2. Quarantine similar messages retroactively.
3. Alert users; advise not to open attachments from unknown senders.
4. If executed, isolate host and run EDR scan.
