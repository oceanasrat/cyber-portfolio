# Phishing Triage Case 01 — Header & IOC Analysis

**Scenario:** A user reported a suspicious invoice email. We parse headers, extract URLs/hashes, and provide a go/no-go verdict with remediation steps.

**Evidence produced:** Raw headers, indicators, and a written findings report.
