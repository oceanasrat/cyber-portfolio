# Recommendations (Top 5)

1. Enforce MFA on all admin accounts and remote access.
2. Implement DMARC (quarantine→reject) with DKIM signing.
3. Establish monthly patch cadence with risk-based SLA.
4. Segment network (user/workload VLANs; restrict DB access).
5. Tabletop-test IR playbooks; close gaps and define comms tree.
