# Internal Security Audit — Controls & Compliance Checklist

**Scope:** Sample small business (Botium Toys–style). Map current controls, identify gaps, and provide recommendations.

**Evidence produced:** Controls checklist (CSV) and recommendations.
