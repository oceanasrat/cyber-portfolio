# Windows Event Hunting — KQL Playbook

**Goal:** Provide ready-to-use Kusto Query Language (KQL) snippets for common detections in Microsoft Sentinel/Defender for Endpoint.

**Evidence produced:** Curated `queries.kql` plus an example dataset and analysis notes.

**Skills:** SIEM basics, KQL, detection triage.
