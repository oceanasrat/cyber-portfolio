# Analyst Notes

- Use queries to filter by host/time and pivot to raw events.
- Validate accounts, logon types, and parent-child process chains.
