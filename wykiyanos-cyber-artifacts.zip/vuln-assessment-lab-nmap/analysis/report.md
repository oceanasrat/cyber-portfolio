# Prioritized Findings

1) **MySQL 5.7.15 exposed (TCP/3306)** — Potential outdated build, network-exposed DB.
   - **Risk:** High
   - **Action:** Restrict to internal allowlist/VPN; upgrade to maintained version.

2) **Apache 2.4.29 (TCP/80)** — Check for known CVEs; enforce HTTPS and security headers.
   - **Risk:** Medium
   - **Action:** Enable TLS, set HSTS, keep patched.

3) **OpenSSH 7.2p2 (TCP/22)** — Enforce key-only auth; rate-limit; consider non-default port with proper controls.
   - **Risk:** Medium

4) **SMB / RDP Exposed (445,3389)** — Lateral movement and brute-force risk if public.
   - **Risk:** High
   - **Action:** Block from internet; require VPN + MFA; enable NLA for RDP.
