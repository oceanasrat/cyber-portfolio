# Vulnerability Assessment Walkthrough (Nmap-based)

**Goal:** Rapid host discovery & service enumeration, then triage likely risks and propose remediations.

**Evidence produced:** Nmap scan text, and a prioritized report.
